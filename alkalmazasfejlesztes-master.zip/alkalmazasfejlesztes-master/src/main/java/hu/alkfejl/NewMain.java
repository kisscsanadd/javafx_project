package hu.alkfejl;

public class NewMain {

    public static void main(String[] args) {
        App.main(args);
    }
}
