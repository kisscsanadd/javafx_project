# Beüzemelés

A ContactDAODBImpl.java fájlban át kell állítani a db elérését vagy a tomcat bin könyvtárába bemásolni a resources/db/contact.db fájlt!
Az asztalihoz képest a webes alkalmazás valamivel egyszerűbb (kevesebbet tud), a Contact-oknál sincs minden opcionális adattag megvalósítva, mint az asztalinál.